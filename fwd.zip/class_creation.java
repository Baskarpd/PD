package day2_programs;

public class class_creation {
	int id;
	String name;
public static void main(String[] args) {
	class_creation c1=new class_creation();
	System.out.println(c1.id);
}
}
