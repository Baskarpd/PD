package Collection;
import java.util.*;
public class ArrayList {
	List list1=new Arraylist()

}
