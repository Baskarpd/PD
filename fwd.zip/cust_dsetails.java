package Entity_Class;

public class cust_dsetails {



		public static void main(String[] args) {

			E_class c1=new E_class();

			c1.setCid(121);

			c1.setName("raghul");

			c1.setAddress("tamil nadu");

			System.out.print(c1);

			

			

			



		}



	}





}
