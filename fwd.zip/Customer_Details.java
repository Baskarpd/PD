package day2_programs;

public class Customer_Details {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Customer c1=new Customer();
		c1.setCid(1008);
		c1.setC_name("KIG");
		c1.setAddress("TN_31");
		System.out.println(c1);
		
	}

}
