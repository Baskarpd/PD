package Inheritance_day3;

public class Person {
	String name;
	String Address;
	int Ph_no;
	
////	class Employee extends Person{
////		int emp_id;
////		float salary;
//	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person p1=new Person();
//		Employee p2=new Person();
		p1.name="Abi";
		p1.Address="YYYYYY";
		System.out.println("Name"+p1);

	}

}
