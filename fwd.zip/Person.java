package day2_programs;

public class Person {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PersonDemo p1=new PersonDemo();
		p1.name="kig";
		System.out.println(p1.name);

	}

}
